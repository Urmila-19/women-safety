// Database simulation using localStorage
const DB = {
    users: JSON.parse(localStorage.getItem('safeher_users')) || [],
    alerts: JSON.parse(localStorage.getItem('safeher_alerts')) || [],
    
    saveUsers: function() {
        localStorage.setItem('safeher_users', JSON.stringify(this.users));
    },
    
    saveAlerts: function() {
        localStorage.setItem('safeher_alerts', JSON.stringify(this.alerts));
    },
    
    findUserByPhone: function(phone) {
        return this.users.find(user => user.phone === phone);
    },
    
    addUser: function(user) {
        this.users.push(user);
        this.saveUsers();
    },
    
    updateUser: function(phone, updates) {
        const userIndex = this.users.findIndex(user => user.phone === phone);
        if (userIndex !== -1) {
            this.users[userIndex] = {...this.users[userIndex], ...updates};
            this.saveUsers();
            return true;
        }
        return false;
    },
    
    addAlert: function(alert) {
        this.alerts.push(alert);
        this.saveAlerts();
    },
    
    getUserAlerts: function(phone) {
        return this.alerts.filter(alert => alert.userPhone === phone);
    }
};

// Current user session
let currentUser = null;

// Audio element for emergency sound
const sirenSound = document.getElementById('siren-sound');
let isSoundPlaying = false;
let isAudioPrepared = false;

// Geolocation and Map variables
let map;
let marker;
let watchId;
let currentLocation = null;

// DOM Elements
const loginModal = document.getElementById('login-modal');
const alertModal = document.getElementById('alert-modal');
const editModal = document.getElementById('edit-modal');
const openLoginBtn = document.getElementById('open-login');
const closeLoginModalBtn = document.getElementById('close-login-modal');
const closeEditModalBtn = document.getElementById('close-edit-modal');
const loginForm = document.getElementById('login-form');
const editContactForm = document.getElementById('edit-contact-form');
const switchToRegisterBtn = document.getElementById('switch-to-register');
const userInfoSection = document.getElementById('user-info');
const userNameSpan = document.getElementById('user-name');
const userPhoneSpan = document.getElementById('user-phone');
const logoutBtn = document.getElementById('logout-btn');
const soundToggleBtn = document.getElementById('sound-toggle');
const locationStatusEl = document.getElementById('location-status');
const aboutLink = document.getElementById('about-link');
const featuresLink = document.getElementById('features-link');
const aboutSection = document.getElementById('about-section');
const featuresDetailSection = document.getElementById('features-detail-section');
const heroGetStartedBtn = document.getElementById('hero-get-started');
const openRegistrationBtn = document.getElementById('open-registration');

// Prepare audio on first user interaction
function prepareAudio() {
    if (isAudioPrepared) return;
    
    // Try to play and immediately pause to "wake up" the audio element
    sirenSound.play().then(() => {
        sirenSound.pause();
        sirenSound.currentTime = 0;
        isAudioPrepared = true;
        console.log("Audio prepared successfully");
    }).catch(error => {
        console.log("Audio preparation failed:", error);
    });
}

// Add event listeners for user interaction to prepare audio
document.addEventListener('click', prepareAudio, { once: true });
document.addEventListener('touchstart', prepareAudio, { once: true });
document.addEventListener('keydown', prepareAudio, { once: true });

// Function to hide all sections and show app interface
function showAppInterface() {
    document.querySelector('.hero').style.display = 'none';
    document.querySelectorAll('.features').forEach(el => el.style.display = 'none');
    document.getElementById('app-tabs').style.display = 'flex';
    document.getElementById('app-interface').style.display = 'flex';
    aboutSection.style.display = 'none';
    featuresDetailSection.style.display = 'none';
    document.getElementById('app-interface').scrollIntoView({ behavior: 'smooth' });
}

// About link functionality
aboutLink.addEventListener('click', function(e) {
    e.preventDefault();
    hideAllSections();
    aboutSection.style.display = 'block';
    aboutSection.scrollIntoView({ behavior: 'smooth' });
});

// Features link functionality
featuresLink.addEventListener('click', function(e) {
    e.preventDefault();
    hideAllSections();
    featuresDetailSection.style.display = 'block';
    featuresDetailSection.scrollIntoView({ behavior: 'smooth' });
});

heroGetStartedBtn.addEventListener('click', function(e) {
    e.preventDefault();
    hideAllSections();
    document.getElementById('app-tabs').style.display = 'flex';
    document.getElementById('app-interface').style.display = 'flex';
    document.getElementById('app-interface').scrollIntoView({ behavior: 'smooth' });
});

openRegistrationBtn.addEventListener('click', function(e) {
    e.preventDefault();
    hideAllSections();
    document.getElementById('app-tabs').style.display = 'flex';
    document.getElementById('app-interface').style.display = 'flex';
    document.getElementById('app-interface').scrollIntoView({ behavior: 'smooth' });
});

// Function to hide all sections
function hideAllSections() {
    document.querySelector('.hero').style.display = 'none';
    document.querySelectorAll('.features').forEach(el => el.style.display = 'none');
    document.getElementById('app-tabs').style.display = 'none';
    document.getElementById('app-interface').style.display = 'none';
    aboutSection.style.display = 'none';
    featuresDetailSection.style.display = 'none';
}

// Open login modal
openLoginBtn.addEventListener('click', () => {
    loginModal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
});

// Close login modal
closeLoginModalBtn.addEventListener('click', () => {
    loginModal.style.display = 'none';
    document.body.style.overflow = 'auto';
});

// Close edit modal
closeEditModalBtn.addEventListener('click', () => {
    editModal.style.display = 'none';
    document.body.style.overflow = 'auto';
});

// Switch to registration from login
switchToRegisterBtn.addEventListener('click', (e) => {
    e.preventDefault();
    loginModal.style.display = 'none';
    showAppInterface();
});

// Login form handling
loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const phone = document.getElementById('login-phone').value;
    const password = document.getElementById('login-password').value;
    
    const user = DB.findUserByPhone(phone);
    
    if (user && user.password === password) {
        currentUser = user;
        loginModal.style.display = 'none';
        document.body.style.overflow = 'auto';
        
        showAppInterface();
        
        // Update user info
        userNameSpan.textContent = user.fullname;
        userPhoneSpan.textContent = user.phone;
        userInfoSection.style.display = 'block';
        
        // Load user data
        loadUserData(user);
        
        alert('Login successful! Welcome back, ' + user.fullname);
    } else {
        alert('Invalid phone number or password. Please try again.');
    }
});

// Logout functionality
logoutBtn.addEventListener('click', () => {
    currentUser = null;
    userInfoSection.style.display = 'none';
    
    // Reset the view
    document.querySelector('.hero').style.display = 'block';
    document.querySelectorAll('.features').forEach(el => el.style.display = 'flex');
    aboutSection.style.display = 'none';
    featuresDetailSection.style.display = 'none';
    document.getElementById('app-tabs').style.display = 'none';
    document.getElementById('app-interface').style.display = 'none';
    
    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
    
    alert('You have been logged out successfully.');
});

// Load user data into forms
function loadUserData(user) {
    document.getElementById('fullname').value = user.fullname || '';
    document.getElementById('phone').value = user.phone || '';
    document.getElementById('email').value = user.email || '';
    document.getElementById('address').value = user.address || '';
    document.getElementById('medical-info').value = user.medicalInfo || '';
    document.getElementById('password').value = user.password || '';
    
    // Load emergency contacts
    const contactsList = document.getElementById('contacts-list');
    contactsList.innerHTML = '';
    
    if (user.emergencyContacts && user.emergencyContacts.length > 0) {
        user.emergencyContacts.forEach((contact, index) => {
            const li = document.createElement('li');
            li.className = 'contact-item';
            li.innerHTML = `
                <div class="contact-info">
                    <div class="contact-name">${contact.name} (${contact.relationship})</div>
                    <div class="contact-number">${contact.phone}</div>
                </div>
                <div class="contact-actions">
                    <button class="action-btn edit-contact" data-index="${index}"><i class="fas fa-edit"></i></button>
                    <button class="action-btn delete delete-contact" data-index="${index}"><i class="fas fa-trash"></i></button>
                </div>
            `;
            contactsList.appendChild(li);
        });
        
        // Add event listeners to edit and delete buttons
        document.querySelectorAll('.edit-contact').forEach(btn => {
            btn.addEventListener('click', function() {
                const index = this.getAttribute('data-index');
                editContact(index);
            });
        });
        
        document.querySelectorAll('.delete-contact').forEach(btn => {
            btn.addEventListener('click', function() {
                const index = this.getAttribute('data-index');
                deleteContact(index);
            });
        });
    }
    
    // Load alert history
    const alertHistory = document.getElementById('alert-history');
    alertHistory.innerHTML = '';
    
    const userAlerts = DB.getUserAlerts(user.phone);
    if (userAlerts.length > 0) {
        userAlerts.forEach(alert => {
            const alertItem = document.createElement('div');
            alertItem.className = 'alert-item';
            alertItem.innerHTML = `
                <div class="alert-date">${new Date(alert.timestamp).toLocaleString()}</div>
                <div class="alert-status">${alert.status}</div>
                <div class="alert-location">Location: ${alert.location.lat ? `Lat: ${alert.location.lat.toFixed(4)}, Lng: ${alert.location.lng.toFixed(4)}` : 'N/A'}</div>
            `;
            alertHistory.appendChild(alertItem);
        });
    } else {
        alertHistory.innerHTML = '<p>No alert history found.</p>';
    }
}

// Edit contact functionality
function editContact(index) {
    const contact = currentUser.emergencyContacts[index];
    
    document.getElementById('edit-contact-index').value = index;
    document.getElementById('edit-contact-name').value = contact.name;
    document.getElementById('edit-contact-phone').value = contact.phone;
    document.getElementById('edit-relationship').value = contact.relationship;
    
    editModal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

// Edit contact form handling
editContactForm.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const index = document.getElementById('edit-contact-index').value;
    const name = document.getElementById('edit-contact-name').value;
    const phone = document.getElementById('edit-contact-phone').value;
    const relationship = document.getElementById('edit-relationship').value;
    
    // Update contact in current user
    currentUser.emergencyContacts[index] = { name, phone, relationship };
    
    // Update user in database
    const userIndex = DB.users.findIndex(user => user.phone === currentUser.phone);
    if (userIndex !== -1) {
        DB.users[userIndex].emergencyContacts = currentUser.emergencyContacts;
        DB.saveUsers();
        
        // Reload user data
        loadUserData(currentUser);
        
        editModal.style.display = 'none';
        document.body.style.overflow = 'auto';
        
        alert('Contact updated successfully!');
    }
});

// Delete contact functionality
function deleteContact(index) {
    if (confirm('Are you sure you want to delete this contact?')) {
        // Remove contact from current user
        currentUser.emergencyContacts.splice(index, 1);
        
        // Update user in database
        const userIndex = DB.users.findIndex(user => user.phone === currentUser.phone);
        if (userIndex !== -1) {
            DB.users[userIndex].emergencyContacts = currentUser.emergencyContacts;
            DB.saveUsers();
            
            // Reload user data
            loadUserData(currentUser);
            
            alert('Contact deleted successfully!');
        }
    }
}

// Registration form handling
document.getElementById('registration-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const fullname = document.getElementById('fullname').value;
    const phone = document.getElementById('phone').value;
    const email = document.getElementById('email').value;
    const address = document.getElementById('address').value;
    const medicalInfo = document.getElementById('medical-info').value;
    const password = document.getElementById('password').value;
    
    // Check if user already exists
    const existingUser = DB.findUserByPhone(phone);
    
    if (existingUser) {
        alert('This phone number is already registered. Please login instead.');
        loginModal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
        return;
    }
    
    // Create new user
    const newUser = {
        fullname,
        phone,
        email,
        address,
        medicalInfo,
        password,
        emergencyContacts: [],
        createdAt: new Date().toISOString()
    };
    
    // Save user to database
    DB.addUser(newUser);
    currentUser = newUser;
    
    // Update UI
    userNameSpan.textContent = newUser.fullname;
    userPhoneSpan.textContent = newUser.phone;
    userInfoSection.style.display = 'block';
    
    alert('Registration successful! Your account has been created.');
    
    // Refresh the page or redirect to main app view if needed
    loadUserData(currentUser);
});

// Add contact functionality
document.getElementById('add-contact').addEventListener('click', function() {
    if (!currentUser) {
        alert('Please register or login first.');
        return;
    }
    
    const name = document.getElementById('contact-name').value;
    const phone = document.getElementById('contact-phone').value;
    const relationship = document.getElementById('relationship').value;
    
    if (name && phone) {
        // Add contact to current user
        const newContact = { name, phone, relationship };
        
        // Update user in database
        const userIndex = DB.users.findIndex(user => user.phone === currentUser.phone);
        if (userIndex !== -1) {
            if (!DB.users[userIndex].emergencyContacts) {
                DB.users[userIndex].emergencyContacts = [];
            }
            DB.users[userIndex].emergencyContacts.push(newContact);
            DB.saveUsers();
            
            // Update current user object
            currentUser = DB.users[userIndex];
            
            // Reload user data
            loadUserData(currentUser);
            
            // Clear input fields
            document.getElementById('contact-name').value = '';
            document.getElementById('contact-phone').value = '';
        }
    } else {
        alert('Please enter both name and phone number');
    }
});

// SOS Button functionality
const sosButton = document.getElementById('sos-button');
const cancelAlert = document.getElementById('cancel-alert');
const alertTimer = document.getElementById('alert-timer');

let countdown;
let timeLeft = 30;

sosButton.addEventListener('click', function() {
    if (!currentUser) {
        alert('Please register or login first.');
        return;
    }
    
    // Show the modal
    alertModal.style.display = 'flex';
    timeLeft = 30;
    alertTimer.textContent = '00:30';
    
    // Update notified contacts
    const notifiedContactsEl = document.getElementById('notified-contacts');
    if (currentUser.emergencyContacts && currentUser.emergencyContacts.length > 0) {
        notifiedContactsEl.textContent = currentUser.emergencyContacts.map(c => c.name).join(', ');
    } else {
        notifiedContactsEl.textContent = 'No contacts available';
    }

    // Play emergency sound
    playEmergencySound();
    
    // Start real-time location tracking
    startLocationTracking();
    
    // Start countdown
    countdown = setInterval(function() {
        timeLeft--;
        alertTimer.textContent = `00:${timeLeft.toString().padStart(2, '0')}`;
        
        if (timeLeft <= 0) {
            clearInterval(countdown);
            stopLocationTracking();
            
            // Create alert record
            const newAlert = {
                userPhone: currentUser.phone,
                timestamp: new Date().toISOString(),
                status: 'Sent to authorities and contacts',
                location: currentLocation
            };
            
            DB.addAlert(newAlert);
            
            // Stop sound
            stopEmergencySound();
            
            alert('Emergency alert has been sent!');
            alertModal.style.display = 'none';
            
            // Refresh alert history if on alerts tab
            if (currentUser) {
                loadUserData(currentUser);
            }
        }
    }, 1000);
});

// Play emergency sound with proper error handling
function playEmergencySound() {
    sirenSound.play().then(() => {
        isSoundPlaying = true;
        soundToggleBtn.innerHTML = '<i class="fas fa-volume-mute"></i> Mute Sound';
    }).catch(error => {
        console.error("Error playing sound:", error);
        // Try to prepare and play again
        prepareAudio();
        setTimeout(() => {
            sirenSound.play().then(() => {
                isSoundPlaying = true;
                soundToggleBtn.innerHTML = '<i class="fas fa-volume-mute"></i> Mute Sound';
            }).catch(error2 => {
                console.error("Still cannot play sound:", error2);
                alert("Sound alert could not be played. Please check your browser's audio settings.");
            });
        }, 500);
    });
}

// Stop emergency sound
function stopEmergencySound() {
    sirenSound.pause();
    sirenSound.currentTime = 0;
    isSoundPlaying = false;
}

// Sound toggle functionality
soundToggleBtn.addEventListener('click', function() {
    if (isSoundPlaying) {
        sirenSound.pause();
        soundToggleBtn.innerHTML = '<i class="fas fa-volume-up"></i> Unmute Sound';
    } else {
        sirenSound.play().then(() => {
            soundToggleBtn.innerHTML = '<i class="fas fa-volume-mute"></i> Mute Sound';
        }).catch(error => {
            console.error("Error playing sound:", error);
            prepareAudio();
        });
    }
    isSoundPlaying = !isSoundPlaying;
});

// Start live location tracking
function startLocationTracking() {
    if (!navigator.geolocation) {
        locationStatusEl.textContent = 'Geolocation is not supported by your browser.';
        return;
    }

    locationStatusEl.textContent = 'Getting your location...';
    
    // Initialize map if it doesn't exist
    if (!map) {
        map = L.map('mapid').setView([0, 0], 13); // Set default view
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '© OpenStreetMap'
        }).addTo(map);
        marker = L.marker([0, 0]).addTo(map);
    }

    watchId = navigator.geolocation.watchPosition(
        function(position) { // Success callback
            const lat = position.coords.latitude;
            const lng = position.coords.longitude;
            currentLocation = { lat, lng };

            // Update map and marker
            const newLatLng = new L.LatLng(lat, lng);
            map.setView(newLatLng, 17);
            marker.setLatLng(newLatLng);
            
            locationStatusEl.textContent = `Location: Lat: ${lat.toFixed(4)}, Lng: ${lng.toFixed(4)}`;

            // Simulate police distance calculation (simple Haversine formula)
            const policeLocation = { lat: lat + 0.01, lng: lng + 0.01 }; // Simulated nearest police station
            const distance = calculateDistance(lat, lng, policeLocation.lat, policeLocation.lng);
            document.getElementById('police-distance').textContent = `${distance.toFixed(2)} km away`;
            
        }, 
        function(error) { // Error callback
            console.error("Geolocation error:", error);
            let message = 'Location access denied.';
            if (error.code === error.PERMISSION_DENIED) {
                message = 'Location access denied. Please enable location services.';
            } else if (error.code === error.POSITION_UNAVAILABLE) {
                message = 'Location information is unavailable.';
            } else if (error.code === error.TIMEOUT) {
                message = 'The request to get user location timed out.';
            }
            locationStatusEl.textContent = message;
        }, 
        { // Options
            enableHighAccuracy: true,
            timeout: 5000,
            maximumAge: 0
        }
    );
}

// Stop live location tracking
function stopLocationTracking() {
    if (watchId) {
        navigator.geolocation.clearWatch(watchId);
        console.log("Location tracking stopped.");
    }
}

// Haversine formula to calculate distance between two points on Earth
function calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371e3; // metres
    const φ1 = lat1 * Math.PI/180; // φ, λ in radians
    const φ2 = lat2 * Math.PI/180;
    const Δφ = (lat2-lat1) * Math.PI/180;
    const Δλ = (lon2-lon1) * Math.PI/180;

    const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ/2) * Math.sin(Δλ/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const d = R * c / 1000; // in km
    return d;
}

cancelAlert.addEventListener('click', function() {
    clearInterval(countdown);
    stopLocationTracking();
    
    // Create cancelled alert record
    const newAlert = {
        userPhone: currentUser.phone,
        timestamp: new Date().toISOString(),
        status: 'Cancelled by user',
        location: currentLocation
    };
    
    DB.addAlert(newAlert);
    
    // Stop sound
    stopEmergencySound();
    
    alertModal.style.display = 'none';
    alert('Emergency alert cancelled.');
    
    // Refresh alert history if on alerts tab
    if (currentUser) {
        loadUserData(currentUser);
    }
});

// Allow closing modal by clicking outside
alertModal.addEventListener('click', function(e) {
    if (e.target === alertModal) {
        clearInterval(countdown);
        stopLocationTracking();
        
        // Stop sound
        stopEmergencySound();
        
        alertModal.style.display = 'none';
    }
});

editModal.addEventListener('click', function(e) {
    if (e.target === editModal) {
        editModal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
});

// Tab navigation functionality
document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
        // Remove active class from all tabs
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        // Add active class to clicked tab
        tab.classList.add('active');
        
        // Hide all tab content
        document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
        // Show the corresponding tab content
        const tabId = tab.getAttribute('data-tab');
        document.getElementById(`${tabId}-tab`).classList.add('active');
    });
});